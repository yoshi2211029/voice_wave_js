// フーリエ変換のサイズ
const fftSize = 8192;

// 解析する最小周波数と最大周波数
const minFrequency = 50;
const maxFrequency = 2000;

// キャンバスの幅と高さ
const width = 100;
const height = 100;

// 初期化関数
const init = async () => {
  // オーディオコンテキストの作成
  const audioContext = new AudioContext();
  const sampleRate = audioContext.sampleRate;
  const analyser = audioContext.createAnalyser();
  analyser.fftSize = fftSize;
  const bufferSize = analyser.frequencyBinCount;
  const buffer = new Uint8Array(bufferSize);

  // ユーザーメディアへのアクセスと解析の設定
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  const input = audioContext.createMediaStreamSource(stream);
  input.connect(analyser);

  // キャンバスとコンテキストの設定
  const canvas = document.getElementById("canvas");
  const ctx = canvas.getContext("2d");

  const toneCanvas = document.getElementById("toneCanvas");
  const toneCtx = toneCanvas.getContext("2d");

  // 最小周波数と最大周波数のインデックス計算
  const minFrequencyIndex = Math.trunc(
    (minFrequency / sampleRate) * bufferSize,
  );
  const maxFrequencyIndex = Math.trunc(
    (maxFrequency / sampleRate) * bufferSize,
  );

  // 描画関数
  const tick = () => {
    requestAnimationFrame(tick);
    analyser.getByteFrequencyData(buffer);

    const subBuffer = [];
    for (let i = 0; i < bufferSize - 1; i++) {
      subBuffer[i] = buffer[i + 1] - buffer[i];
    }

    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, width, height);

    toneCtx.fillStyle = "#000";
    toneCtx.fillRect(0, 0, width, height);

    let bigWaveFlag = false;
    let bigWaveIndex = 0;
    for (let i = minFrequencyIndex; i < maxFrequencyIndex; i++) {
      const h = (buffer[i] / 256) * height;
      // const sh = (subBuffer[i] / 256 + 0.5) * height;
      const x =
        ((i - minFrequencyIndex) / (maxFrequencyIndex - minFrequencyIndex)) *
        width;
      if (!bigWaveFlag && subBuffer[i] / 256 > 0.1 && buffer[i] > 50) {
        bigWaveFlag = true;
      }
    //   console.log("buffer:" + buffer[i]);
    //   console.log("subBuffer:" + subBuffer[i]);
      if (
        bigWaveFlag &&
        !bigWaveIndex &&
        subBuffer[i] <= 0 &&
        buffer[i] / 256 > 0.2
      ) {
        bigWaveIndex = i;
        console.log("bigWave");
      }

      ctx.fillStyle = "#f00";
      if (bigWaveIndex === i) {
        ctx.fillStyle = "#ff0";
      }
      ctx.fillRect(x, height - h, 2, h);
      // ctx.fillRect(x, height - sh, 2, sh);
    }
    let tone = "";
    if (bigWaveIndex) {
      const bigWaveFrequency = (bigWaveIndex / bufferSize) * sampleRate;
      const ratio = Math.log(bigWaveFrequency / 110) / Math.log(2);
      const toneIndex = Math.round(((ratio + 1000) % 1) * 12);
      const toneList = [
        "ラ",
        "ラ#",
        "シ",
        "ド",
        "ド#",
        "レ",
        "レ#",
        "ミ",
        "ファ",
        "ファ#",
        "ソ",
        "ソ#",
        "ラ",
      ];
      tone = toneList[toneIndex];

      toneCtx.fillStyle = "#ff0";
      toneCtx.fillRect(0, 100 - (ratio / 4) * 100, 100, 3);
    //   document.getElementById("output").textContent = toneIndex;
      document.getElementById("toneLyrics").textContent = tone;
    }
  };
  tick();
};

// ウィンドウの読み込み時に初期化関数を呼び出す
window.onload = () => {
  document.getElementById("start").onclick = () => {
    init();
  };
};
